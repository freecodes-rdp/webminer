declare module "node:path/win32" {
    import path = require("node:path");
    export = path.win32;
}
declare module "path/win32" {
    import path = require("path");
    export = path.win32;
}
