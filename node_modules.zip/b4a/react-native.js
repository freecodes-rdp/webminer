try {
  module.exports = require('react-native-b4a')
} catch {
  module.exports = require('./browser')
}
