const events = require('./web')

global.Event = events.Event
global.CustomEvent = events.CustomEvent
global.EventTarget = events.EventTarget
