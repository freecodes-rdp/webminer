# bare-os

Operating system utilities for Javascript.

```
npm i bare-os
```

## License

Apache-2.0
