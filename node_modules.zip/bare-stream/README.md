# bare-stream

Streaming data for JavaScript.

```
npm i bare-stream
```

## API

See <https://github.com/mafintosh/streamx>.

## License

Apache-2.0
