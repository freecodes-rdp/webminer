const stream = require('./web')

global.ReadableStream = stream.ReadableStream
global.ReadableStreamDefaultController = stream.ReadableStreamDefaultController
global.ReadableStreamDefaultReader = stream.ReadableStreamDefaultReader

global.CountQueuingStrategy = stream.CountQueuingStrategy
global.ByteLengthQueuingStrategy = stream.ByteLengthQueuingStrategy

global.WritableStream = stream.WritableStream
global.WritableStreamDefaultController = stream.WritableStreamDefaultController
global.WritableStreamDefaultReader = stream.WritableStreamDefaultReader
