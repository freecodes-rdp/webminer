const stream = require('streamx')

exports.pipeline = stream.pipelinePromise
