# bare-url

WHATWG URL implementation for JavaScript.

```
npm i bare-url
```

## Usage

```js
const url = require('bare-url')

const p = url.fileURLToPath('file:///foo') // --> /foo
```

## License

Apache-2.0
