global.URL = require('.')
global.URLSearchParams = require('./lib/url-search-params')
