import debug from 'debug';
export declare const debugInfo: debug.Debugger;
export declare class WebSocketServer {
    #private;
    constructor(port: number, verbose: boolean);
}
