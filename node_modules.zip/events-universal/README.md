# events-universal

Universal wrapper for the Node.js `events` module.

```
npm i events-universal
```

## Usage

```js
const EventEmitter = require('events-universal')
```

## License

Apache-2.0
