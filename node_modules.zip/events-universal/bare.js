module.exports = require('bare-events')
